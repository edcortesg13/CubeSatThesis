syms Ixx; syms Iyy; syms Izz;
syms hx; syms hy; syms hz;
syms hhx; syms hhy; syms hhz;
syms phi; syms psi; syms tht;
syms pphi; syms ppsi; syms ttht;
grav=1.5*1.5416618080299*10^(-6);


GRAVEDAD=grav*[(Izz-Iyy)*sin(2*phi)*cos(tht)*cos(tht);
           (Izz-Ixx)*sin(2*tht)*cos(phi);
           (Ixx-Iyy)*sin(phi)*sin(tht)*sin(tht)];
       
R1=[1 0 -sin(tht);
    0 cos(phi) cos(tht)*sin(phi);
    0 -sin(phi) cos(tht)*cos(phi)];       

R2=[0 0 -ttht*cos(tht);
    -pphi*sin(phi) -ppsi*sin(tht)*sin(phi) pphi*cos(tht)*cos(phi);
    -ttht*cos(phi) -ppsi*sin(tht)*cos(phi) -pphi*cos(tht)*sin(phi)];

R3=[0, -(ppsi*cos(tht)*cos(phi)-ttht*sin(phi)), pphi*cos(phi)+ppsi*cos(tht)*sin(phi);
    ppsi*cos(tht)*cos(phi)-ttht*sin(phi),0, -(pphi-ppsi*sin(tht));
    -(ttht*cos(phi)+ppsi*cos(tht)*sin(phi)), pphi-ppsi*sin(tht), 0];

I=[Ixx 0 0; 0 Iyy 0; 0 0 Izz];
omega=[pphi;ttht;ppsi];
h=[hx;hy;hz];
hh=[hhx;hhy;hhz];


grados=inv(R1)*(I*(GRAVEDAD-R3*h-R3*I*R1*omega-hh)-R2*omega);