% Make some building blocks
a = zeros(3,3);
athree = zeros(3,1);
unos=[1;1;1];
I = eye(3,3);

% Define the initial quaternion
qfour = 1;
q = 1/2 * qfour * I;



J = [1.2, 0.006, 0.2 ; 0.006, 0.8, 0.005; 0.2, 0.005, 1.1];

% Define your A, B, C, and D Full-State Linear System

% Dynamics Matrix A
A = [a, a, I; q, a, a; a, a, I];
%A = [q, a, athree; a, a, athree;  athree', athree', 0];
%A1 = [a, a; q, a ];

% Inputs Matrix B
%B = [inv(J); zeros(4,3)]
B = [inv(J); a;a];
%B = [a;inv(J);  athree'];
% Outputs vs. State Matrix C
%C = [I, a, athree; a, I, athree; athree', athree', 1];
C1 = [I, a, athree; a, I, athree; athree', athree', 1];
C = [I, a, I];

% Outputs vs. Inputs Matrix D
%D = zeros(7,3);
%D = zeros(6,3);
D = zeros(3,3); 


sys=ss(A,B,C,D);

%% Control LQR
Q=C'*C;

R=  eye(3);


[K,S,E]=lqr(A,B,Q,R);

figure(1)
step(sys)

syscl=ss(A-B*K,B,C,D);

figure(2)
step(syscl)

%% H INFINITO 
% FIGURAS COMENTADAS PARA TRABAJO EN SIMULINK, DESCOMENTAR PAR VISUALIZAR
%Glat21=ss(Alat,Blat(:,2),[Clat(2,:);Clat(4,:)],[Dlat(2,2);Dlat(4,2)]); 
%%%%%%%%%%%%%VALORES PARA FILTROS %%%%%%%%%%%%%%
M1 = 1;                                    %%% 
Aa1 = 6;                                  %%%    
Wb1 = pi;                              %%% mayor a 2pi*8hz   
                                            %%%    
M3 = 0.2;                                  %%%    
Aa3 = 1;                                    %%%    
Wb3 = 1;                             %%% Frecuencia alta   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M1 = 10;                                    %%% 10
% Aa1 = 0.06;                                  %%%  0.06  
% Wb1 = 2*pi;                              %%% 2pi hz   
%                                             %%%    
% M3 = 0.002;                                  %%% 0.002   
% Aa3 = 40;                                    %%% 50   
% Wb3 = 2*pi*100;                             %%% 2pi*130



Wp      = 2*tf(1,1)*eye(3);                    %Perturbaciones
W1      = tf([1/M1 Wb1],[1 Aa1*Wb1])*eye(3);    %Seguimiento de Referencias, rechazo de perturbaciones
W2      = 0.06*tf(1,1)*eye(3);                 %Esfuerzo de Control 0.3 - 0.6 - 0.02
W3      = tf([1/M3 Wb3],[1 Aa3*Wb3])*eye(3);    %Rechazo de Perturbaciones
Wn      = 0.1*tf(1,1)*eye(3);                        %Ruido



%EL C�DIGO SOLO ME CORRE CUANDO n y r EST�N DEFINIDAS CON ESA DIMENSI�N {3}

systemnames      = 'sys Wp Wn W1 W2 W3';
inputvar         = '[p{3}; n{3} ;r{3} ;u{3}]';
outputvar        = '[W1;W2;W3;-sys - Wn +r ]';
input_to_sys     = '[Wp + u]';
input_to_Wp      = '[p]';
input_to_Wn      = '[n]';
input_to_W1      = '[-sys - Wn + r]';
input_to_W2      = '[u]';
input_to_W3      = '[sys]';
Cube_sys        = sysic;


%% Controlador

ncont = 9;
nmeas = 9;
[K3,CL,gam1,info] = hinfsyn(Cube_sys,nmeas,ncont);

%% Lazo cerrado SIN filtros
display('Polos del controlador')
eig(K3)
%%

systemnames      = 'sys K3';
 inputvar        = '[r{3}]';
 outputvar       = '[-sys + r]';
input_to_sys  ='[K3]';
input_to_K3 = '[r-sys]';
Contr_Cube_S  =sysic;
 
%  figure (1)
%  subplot(2,1,1);
%  step(Contr_Cube_S)
 
 %ESTABLECIMIENTO PLANTA  INTERCONECTADA T 
systemnames     = 'sys K3';
 inputvar        = '[r{3}]';
 outputvar       = '[sys]';
input_to_sys  ='[K3]';
input_to_K3 = '[r-sys]';

 Contr_Cube_T=sysic;

 %  figure (1)
%  subplot(2,1,2);
%  step(Contr_Cube_T)

%% Comprobacion W1(S)
figure (3)
 bodemag(Contr_Cube_S,'r');
 grid on
 hold on
 bodemag(1/W1,'g');

%% Comprobacion W2


figure(4)
bodemag(K3*Contr_Cube_S,'r');
hold on
grid on
bodemag(1/W2,'g');

 %% Comprobacion W3

figure (5)
bodemag(Contr_Cube_T,'r');
hold on
grid on
bodemag(1/W3,'g');